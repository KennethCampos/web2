// routes/index.js
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({
    status_code: 200,
    status_message: 'Ok',
    data: {
      title: 'Categories API',
      description: 'API ejemplo usando categorías de Northwind en MongoDB'
    }
  });
});

module.exports = router;
