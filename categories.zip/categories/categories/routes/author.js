// routes/author.js
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({
    status_code: 200,
    status_message: 'Ok',
    data: {
      name: 'Andres Arias',     
      nickname: 'Popeye', 
      occupation: 'Estudiante TI'
    }
  });
});

module.exports = router;
