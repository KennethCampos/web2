// routes/comment.js
const express = require('express');
const router = express.Router();
const Research = require('../models/mdlResearch'); // tu modelo de investigaciones

// POST agregar comentario a investigación
router.post('/:id', async (req, res, next) => {
  try {
    const { text, rating } = req.body;

    // Buscar la investigación por id
    const research = await Research.findById(req.params.id);
    if (!research) {
      return res.status(404).json({ status_code: 404, status_message: "Not Found", error: "Investigación no encontrada" });
    }

    // Inicializar el array de comentarios si no existe
    if (!research.comments) research.comments = [];

    // Agregar el comentario
    research.comments.push({ text, rating });

    // Guardar cambios en MongoDB
    await research.save();

    res.status(201).json({ status_code: 201, status_message: "Created", data: research.comments });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
