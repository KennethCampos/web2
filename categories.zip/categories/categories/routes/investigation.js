const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });

const Research = require('../models/mdlResearch'); // tu modelo para investigaciones

// ==========================
// Listado de investigaciones
// ==========================
router.get('/', async (req, res, next) => {
  try {
    const { area, studentGrade } = req.query;

    let filter = {};
    if (area) filter.area = area;
    if (studentGrade) filter.studentGrade = studentGrade;

    const researches = await Research.find(filter).sort({ title: 1 }).lean();

    res.json({ status_code: 200, status_message: "Ok", data: researches });
  } catch (err) { next(err); }
});

// ====================================
// Detalle de investigación por ID
// ====================================
router.get('/:id', async (req, res, next) => {
  try {
    const research = await Research.findById(req.params.id).lean();
    if (!research)
      return res.status(404).json({ status_code: 404, status_message: "Not Found" });

    res.json({ status_code: 200, status_message: "Ok", data: research });
  } catch (err) { next(err); }
});

// ====================================
// Subir investigación (pdf + images)
// ====================================
router.post('/', upload.fields([
  { name: 'pdf', maxCount: 1 },
  { name: 'images', maxCount: 6 }
]), async (req, res, next) => {
  try {
    const meta = JSON.parse(req.body.meta); // JSON con los datos de investigación
    const { title, area, description, conclusions, recommendations, studentName, studentEmail, studentGrade, captions } = meta;

    const pdf = req.files['pdf'][0];
    const images = req.files['images']?.map((file, i) => ({
      image: file.buffer,
      imageMime: file.mimetype,
      caption: captions[i] || ""
    })) || [];

    const newResearch = new Research({
      title,
      area,
      description,
      pdf: pdf.buffer,
      pdfMime: pdf.mimetype,
      images,
      conclusions,
      recommendations,
      studentName,
      studentEmail,
      studentGrade,
      comments: []
    });

    await newResearch.save();
    res.status(201).json({ status_code: 201, status_message: "Created", data: newResearch });
  } catch (err) { next(err); }
});

// ==========================
// Agregar comentario
// ==========================
router.post('/:id/comment', async (req, res, next) => {
  try {
    const { text, rating } = req.body;

    if (!text || text.length > 100)
      return res.status(400).json({ status_code: 400, status_message: "Bad Request", error: "Comentario inválido" });

    if (!rating || rating < 1 || rating > 5)
      return res.status(400).json({ status_code: 400, status_message: "Bad Request", error: "Calificación inválida" });

    const research = await Research.findById(req.params.id);
    if (!research) return res.status(404).json({ status_code: 404, status_message: "Not Found" });

    // Inicializar array si no existe
    if (!research.comments) research.comments = [];

    research.comments.push({ text, rating });
    await research.save();

    res.status(201).json({ status_code: 201, status_message: "Created", data: research });
  } catch (err) { next(err); }
});

module.exports = router;
