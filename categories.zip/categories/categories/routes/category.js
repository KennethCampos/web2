// routes/category.js
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const Category = mongoose.model('Categories');

// GET todas
router.get('/', async (req, res, next) => {
  try {
    let cats = await Category.find({}).lean();
    if (cats.length === 0) cats = { message: 'La lista está vacía' };
    res.json({ status_code: 200, status_message: 'Ok', data: cats });
  } catch (err) { next(err); }
});

// GET una por ID
router.get('/:id', async (req, res, next) => {
  try {
    const cat = await Category.findOne({ CategoryID: req.params.id }).lean();
    if (!cat) {
      return res.status(404).json({
        status_code: 404,
        status_message: 'Not Found',
        data: { message: 'Categoría no encontrada' }
      });
    }
    res.json({ status_code: 200, status_message: 'Ok', data: cat });
  } catch (err) { next(err); }
});

// POST crear
// POST crear categoría
router.post('/', async (req, res, next) => {
  try {
    const { CategoryID, CategoryName, Description, Mime, Image } = req.body;

    // Crear la categoría
    const cat = new Category({
      CategoryID,
      CategoryName,
      Description,
      Mime,
      Image: Image ? Buffer.from(Image, 'base64') : undefined
    });

    await cat.save();

    // Convertir la imagen de Buffer a Base64 para la respuesta
    const responseData = {
      CategoryID: cat.CategoryID,
      CategoryName: cat.CategoryName,
      Description: cat.Description,
      Mime: cat.Mime,
      Image: cat.Image ? cat.Image.toString('base64') : null,
      _id: cat._id
    };

    res.status(201).json({
      status_code: 201,
      status_message: 'Created',
      data: responseData
    });
  } catch (err) {
    next(err);
  }
});


// PUT actualizar
router.put('/', async (req, res, next) => {
  try {
    const { CategoryID, CategoryName, Description, Mime, Image } = req.body;
    const updated = await Category.updateOne(
      { CategoryID },
      {
        $set: {
          CategoryName,
          Description,
          Mime,
          Image: Image ? Buffer.from(Image, 'base64') : undefined
        }
      }
    );
    if (updated.matchedCount === 0) {
      return res.status(404).json({
        status_code: 404,
        status_message: 'Not Found',
        data: { message: 'Categoría no encontrada' }
      });
    }
    res.json({ status_code: 200, status_message: 'Ok', data: 'Actualizado' });
  } catch (err) { next(err); }
});

// DELETE eliminar
router.delete('/', async (req, res, next) => {
  try {
    const { CategoryID } = req.body;
    const deleted = await Category.deleteOne({ CategoryID });
    if (deleted.deletedCount === 0) {
      return res.status(404).json({
        status_code: 404,
        status_message: 'Not Found',
        data: { message: 'Categoría no encontrada' }
      });
    }
    res.json({ status_code: 200, status_message: 'Ok', data: 'Eliminado' });
  } catch (err) { next(err); }
});

module.exports = router;
