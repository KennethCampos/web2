const express = require('express');
const router = express.Router();
const Student = require('../models/mdlStudent');

// GET todos los estudiantes
router.get('/', async (req, res, next) => {
  try {
    const students = await Student.find().lean();
    res.json({ status_code: 200, status_message: "Ok", data: students });
  } catch (err) {
    next(err);
  }
});

// GET estudiante por _id
router.get('/:id', async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id).lean();
    if (!student) {
      return res.status(404).json({ status_code: 404, status_message: "Not Found", data: null });
    }
    res.json({ status_code: 200, status_message: "Ok", data: student });
  } catch (err) {
    next(err);
  }
});

// POST registrar estudiante
router.post('/', async (req, res, next) => {
  try {
    const { fullName, email, password, grade, bio, photo, photoMime } = req.body;

    const newStudent = new Student({
      fullName,
      email,
      password,                 // O hash con bcrypt si quieres mayor seguridad
      grade,
      bio,
      photo: photo ? Buffer.from(photo, 'base64') : undefined,
      photoMime
    });

    await newStudent.save();

    res.status(201).json({ status_code: 201, status_message: "Created", data: newStudent });
  } catch (err) {
    next(err);
  }
});

// PUT actualizar estudiante por _id
router.put('/:id', async (req, res, next) => {
  try {
    const { fullName, email, password, grade, bio, photo, photoMime } = req.body;

    const updated = await Student.findByIdAndUpdate(
      req.params.id,
      {
        fullName,
        email,
        password,
        grade,
        bio,
        ...(photo ? { photo: Buffer.from(photo, 'base64'), photoMime } : {})
      },
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ status_code: 404, status_message: "Not Found" });
    }

    res.json({ status_code: 200, status_message: "Ok", data: updated });
  } catch (err) {
    next(err);
  }
});

// DELETE estudiante por _id
router.delete('/:id', async (req, res, next) => {
  try {
    const deleted = await Student.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ status_code: 404, status_message: "Not Found" });
    }
    res.json({ status_code: 200, status_message: "Ok", data: deleted });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
