// Load libraries
var createError = require('http-errors');
var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');
var helmet = require('helmet');

const investigationRouter = require('./routes/investigation');



// Creates application
var app = express();

// Middlewares
app.use(bodyParser.json({ type: 'application/json' }));
app.use(cors());
app.use(helmet());

// Conexión MongoDB (importa tu módulo connectDB.js)
const connectDB = require('./database');
connectDB();

// Importar modelos
require('./models/mdlArticle');
require('./models/mdlCategory'); 
require('./models/mdlStudent')

// Importar rutas
var indexRouter    = require('./routes/index');
var authorRouter   = require('./routes/author');
var articleRouter  = require('./routes/article');
var commentRouter  = require('./routes/comment');
var categoryRouter = require('./routes/category');
var studentRouter  = require('./routes/student');

// Usar rutas
app.use('/', indexRouter);
app.use('/author', authorRouter);
app.use('/article', articleRouter);
app.use('/comment', commentRouter);
app.use('/category', categoryRouter);
app.use('/student', studentRouter);
app.use('/investigation', investigationRouter);

// Error 404
app.use((req, res, next) => {
  res.status(404).json({
    status_code: 404,
    status_message: "Ruta no encontrada"
  });
});

// Error handler general
app.use((err, req, res, next) => {
  console.error("❌ Error:", err);
  res.status(500).json({
    status_code: 500,
    status_message: "Internal Server Error",
    error: err.message
  });
});

// Iniciar servidor
var server = app.listen(5005, () => {
  console.log(`🚀 Server is listening on port ${server.address().port}`);
});
