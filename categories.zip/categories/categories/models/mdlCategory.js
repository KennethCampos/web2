// models/mdlCategory.js
var mongoose = require('mongoose');

var schCategory = new mongoose.Schema({
  CategoryID:   { type: String, required: true, unique: true },
  CategoryName: { type: String, required: true },
  Description:  { type: String, required: false },
  Image:        { type: Buffer },   // para guardar el binario de la imagen
  Mime:         { type: String }    // tipo de imagen (ej: image/png)
});

mongoose.model('Categories', schCategory);
