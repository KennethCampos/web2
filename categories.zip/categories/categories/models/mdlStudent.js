const mongoose = require('mongoose');

const schStudent = new mongoose.Schema({
  fullName: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, match: /.+\@.+\..+/ },
  password: { type: String, required: true },
  grade: { type: String, required: true },
  bio: { type: String, trim: true },
  photo: { type: Buffer },        // Imagen en binario
  photoMime: { type: String },    // Tipo MIME de la imagen
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Student', schStudent);
