const mongoose = require('mongoose');

const schResearch = new mongoose.Schema({
  title:       { type: String, required: true },
  area:        { type: String, required: true },
  description: { type: String, required: true, maxlength: 500 },
  pdf:         { type: Buffer, required: true },
  pdfMime:     { type: String, required: true },
  images: [
    {
      image: { type: Buffer, required: true },
      imageMime: { type: String, required: true },
      caption: { type: String, maxlength: 200 }
    }
  ],
  conclusions:    { type: String, maxlength: 500 },
  recommendations:{ type: String, maxlength: 500 },
  studentEmail:   { type: String, required: true } // relación con estudiante
}, { timestamps: true });

module.exports = mongoose.model('Research', schResearch);
